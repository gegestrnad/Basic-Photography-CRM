Photo Client tracker / Management
