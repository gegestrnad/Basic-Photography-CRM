/* ==========================================================
   Photography Tracker — Data Store & Helpers
   localStorage-backed CRUD store.
   Auto-generated from Scheduling Plan Obsidian.xlsx
   ========================================================== */

// ── HELPERS ───────────────────────────────────────────────

/** Convert Excel serial date to a Date object */
function excelDateToJS(serial) {
  if (!serial && serial !== 0) return null;
  const epoch = new Date(1899, 11, 30);
  return new Date(epoch.getTime() + (serial - 2) * 86400000);
}

/** Format a Date as "DD MMM YYYY" (e.g. "12 Jun 2026") */
function formatDate(serial) {
  const d = excelDateToJS(serial);
  if (!d) return '—';
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

/** Format number as Indonesian Rupiah */
function formatCurrency(amount) {
  if (amount == null || isNaN(amount)) return 'Rp0';
  return 'Rp' + Math.round(amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

/** CSS class for a job-status badge */
function jobStatusClass(status) {
  const map = {
    'Inquiry':'status-inquiry','Booked':'status-booked','Shot':'status-shot',
    'Editing':'status-editing','Ready':'status-ready','Delivered':'status-delivered',
    'Completed':'status-completed','Cancelled':'status-cancelled'
  };
  return map[status] || 'status-default';
}

/** CSS class for a payment-status badge */
function paymentStatusClass(s) {
  const map = {'UNPAID':'status-unpaid','Deposit-Paid':'status-deposit','PAID':'status-paid','Refunded':'status-refunded'};
  return map[s] || 'status-default';
}

/** CSS class for a task-status badge */
function taskStatusClass(s) {
  const map = {'OPEN':'status-open','IN PROGRESS':'status-in-progress','WAITING':'status-waiting','DONE':'status-done','CANCELLED':'status-cancelled'};
  return map[s] || 'status-default';
}

/** Format date relative to today */
function formatDateRelative(serial) {
  const d = excelDateToJS(serial);
  if (!d) return '—';
  const today = new Date(); today.setHours(0,0,0,0);
  const target = new Date(d); target.setHours(0,0,0,0);
  const diff = Math.round((target - today) / 86400000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Tomorrow';
  if (diff === -1) return 'Yesterday';
  return formatDate(serial);
}

/** Convert YYYY-MM-DD string to Excel serial date */
function dateToExcel(ymd) {
  if (!ymd) return null;
  const parts = ymd.split('-');
  const d = new Date(+parts[0], +parts[1] - 1, +parts[2]);
  const epoch = new Date(1899, 11, 30);
  return Math.round((d.getTime() - epoch.getTime()) / 86400000) + 2;
}

/** Convert Excel serial to YYYY-MM-DD for date input */
function excelToDateInput(serial) {
  const d = excelDateToJS(serial);
  if (!d) return '';
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/** Escape HTML */
function escHtml(s) {
  if (!s) return '';
  var d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

/** Show a toast notification */
function showToast(msg, duration) {
  duration = duration || 2000;
  var existing = document.querySelector('.toast');
  if (existing) existing.remove();
  var el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(function() { el.remove(); }, duration);
}

// ── SEED DATA ─────────────────────────────────────────────

var SEED_DATA = {
  jobs: [{
    id: 'JOB-0001', client: 'Isna & Edrika', phone: '',
    jobType: 'Wedding', jobDate: 46187,
    location: 'Kantor Camat Sui. Raya',
    status: 'Editing', paymentStatus: 'PAID',
    totalFee: 1600000, deposit: 1600000, balance: 0,
    photographers: 'Gege, Sude', editors: 'Gege',
    clientSource: 'Referral', created: 46193, notes: ''
  }],
  payments: [{
    id: 'PAY-0001', jobId: 'JOB-0001', client: 'Isna & Edrika',
    paymentDate: 46188, amount: 1600000, method: 'Cash',
    status: 'PAID', jobTotalFee: 1600000, jobBalance: 0, notes: ''
  }],
  tasks: [{
    id: 'TSK-0001', jobId: 'JOB-0001', client: 'Isna & Edrika',
    task: 'Editing', dueDate: 46194,
    status: 'IN PROGRESS', notes: ''
  }],
  lists: {
    jobStatuses: ['Inquiry','Booked','Shot','Editing','Ready','Delivered','Completed','Cancelled'],
    paymentStatuses: ['UNPAID','Deposit-Paid','PAID','Refunded'],
    clientSources: ['WhatsApp','Facebook','Instagram','Referral','Returning Client','Website','Other'],
    jobTypes: ['Wedding','Engagement','Company Event','Portrait','Family','Product','Other'],
    taskStatuses: ['OPEN','IN PROGRESS','WAITING','DONE','CANCELLED'],
    paymentMethods: ['Cash','Bank Transfer','QRIS','E-wallet','Card','Other'],
    wageRules: [
      { role: 'Photographer A', percentage: 0.30 },
      { role: 'Photographer B', percentage: 0.24 },
      { role: 'Manager / Client Relations', percentage: 0.29 },
      { role: 'Photo Editor', percentage: 0.12 },
      { role: 'General Staff / Operational & Misc', percentage: 0.05 }
    ],
    wageConfig: {
      distributableRatio: 0.625
    },
    staff: [
      { name: 'Gege', role: 'Photographer', roles: ['Photographer A', 'Photo Editor'] },
      { name: 'Sude', role: 'Editor', roles: ['Photographer B', 'General Staff / Operational & Misc'] },
      { name: 'Roni', role: 'Assistant Photographer', roles: ['Manager / Client Relations'] }
    ]
  },
  wageDistributions: []
};

// ── DATA STORE ────────────────────────────────────────────

var STORAGE_KEY = 'photo_tracker_data';

function generateId(prefix, existing) {
  var nums = existing.map(function(item) {
    var n = parseInt(item.id.replace(/^[A-Z]+-/, ''), 10);
    return isNaN(n) ? 0 : n;
  });
  var max = nums.length > 0 ? Math.max.apply(null, nums) : 0;
  return prefix + '-' + String(max + 1).padStart(4, '0');
}

function computeMetrics(jobs, tasks) {
  var now = new Date(); now.setHours(0,0,0,0);
  return {
    activeJobs: jobs.filter(function(j) { return j.status !== 'Completed' && j.status !== 'Cancelled'; }).length,
    upcomingActiveJobs: jobs.filter(function(j) {
      var d = excelDateToJS(j.jobDate);
      return d && d >= now && j.status !== 'Completed' && j.status !== 'Cancelled';
    }).length,
    jobsInEditing: jobs.filter(function(j) { return j.status === 'Editing'; }).length,
    outstandingBalance: jobs.reduce(function(sum, j) { return sum + (j.balance || 0); }, 0),
    openTasks: tasks.filter(function(t) { var s = t.status.toUpperCase(); return s !== 'DONE' && s !== 'CANCELLED'; }).length,
    overdueOpenTasks: tasks.filter(function(t) {
      var s = t.status.toUpperCase();
      if (s === 'DONE' || s === 'CANCELLED') return false;
      var d = excelDateToJS(t.dueDate);
      return d && d < now;
    }).length
  };
}

var DataStore = {
  _data: null,
  _listeners: [],

  _load: function() {
    if (this._data) return this._data;
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (raw) { this._data = JSON.parse(raw); }
    } catch(e) { /* ignore */ }
    if (!this._data) {
      this._data = JSON.parse(JSON.stringify(SEED_DATA));
      this._save();
    }
    return this._data;
  },

  _save: function() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(this._data));
    this._notify();
  },

  _notify: function() {
    for (var i = 0; i < this._listeners.length; i++) { this._listeners[i](); }
  },

  onChange: function(fn) {
    this._listeners.push(fn);
  },

  // ── Jobs ──
  getJobs: function()    { return this._load().jobs; },
  getJob: function(id)   { return this._load().jobs.find(function(j) { return j.id === id; }) || null; },

  addJob: function(job) {
    var d = this._load();
    job.id = generateId('JOB', d.jobs);
    job.created = dateToExcel(new Date().toISOString().slice(0, 10));
    d.jobs.push(job);
    this._save();
    return job;
  },

  updateJob: function(id, changes) {
    var d = this._load();
    var idx = d.jobs.findIndex(function(j) { return j.id === id; });
    if (idx === -1) return false;
    for (var key in changes) { if (changes.hasOwnProperty(key)) d.jobs[idx][key] = changes[key]; }
    this._save();
    return true;
  },

  deleteJob: function(id) {
    var d = this._load();
    var idx = d.jobs.findIndex(function(j) { return j.id === id; });
    if (idx === -1) return false;
    d.jobs.splice(idx, 1);
    d.payments = d.payments.filter(function(p) { return p.jobId !== id; });
    d.tasks = d.tasks.filter(function(t) { return t.jobId !== id; });
    if (d.wageDistributions) d.wageDistributions = d.wageDistributions.filter(function(w) { return w.jobId !== id; });
    this._save();
    return true;
  },

  // ── Payments ──
  getPayments: function()           { return this._load().payments; },
  getPaymentsByJob: function(jobId) { return this._load().payments.filter(function(p) { return p.jobId === jobId; }); },

  addPayment: function(payment) {
    var d = this._load();
    payment.id = generateId('PAY', d.payments);
    d.payments.push(payment);
    // Sync: reduce the job's balance by the payment amount
    if (payment.jobId) {
      var job = d.jobs.find(function(j) { return j.id === payment.jobId; });
      if (job) {
        job.balance = Math.max(0, (job.balance || 0) - payment.amount);
      }
    }
    this._save();
    return payment;
  },

  deletePayment: function(id) {
    var d = this._load();
    var idx = d.payments.findIndex(function(p) { return p.id === id; });
    if (idx === -1) return false;
    var payment = d.payments[idx];
    d.payments.splice(idx, 1);
    // Sync: restore the job's balance by the payment amount
    if (payment.jobId) {
      var job = d.jobs.find(function(j) { return j.id === payment.jobId; });
      if (job) {
        job.balance = (job.balance || 0) + payment.amount;
      }
    }
    this._save();
    return true;
  },
  updatePayment: function(id, changes) {
    var d = this._load();
    var idx = d.payments.findIndex(function(p) { return p.id === id; });
    if (idx === -1) return false;
    var oldAmount = d.payments[idx].amount;
    for (var key in changes) { if (changes.hasOwnProperty(key)) d.payments[idx][key] = changes[key]; }
    var payment = d.payments[idx];
    // Re-sync job balance: restore old amount, apply new amount
    if (payment.jobId) {
      var job = d.jobs.find(function(j) { return j.id === payment.jobId; });
      if (job) {
        job.balance = Math.max(0, (job.balance || 0) + oldAmount - payment.amount);
      }
    }
    this._save();
    return true;
  },

  // ── Tasks ──
  getTasks: function()           { return this._load().tasks; },
  getTasksByJob: function(jobId) { return this._load().tasks.filter(function(t) { return t.jobId === jobId; }); },

  addTask: function(task) {
    var d = this._load();
    task.id = generateId('TSK', d.tasks);
    d.tasks.push(task);
    this._save();
    return task;
  },

  updateTask: function(taskId, changes) {
    var d = this._load();
    var idx = d.tasks.findIndex(function(t) { return t.id === taskId; });
    if (idx === -1) return false;
    for (var key in changes) { if (changes.hasOwnProperty(key)) d.tasks[idx][key] = changes[key]; }
    this._save();
    return true;
  },

  deleteTask: function(taskId) {
    var d = this._load();
    var idx = d.tasks.findIndex(function(t) { return t.id === taskId; });
    if (idx === -1) return false;
    d.tasks.splice(idx, 1);
    this._save();
    return true;
  },

  // ── Lists ──
  getLists: function() { return this._load().lists; },

  // ── Wage Rules & Config ──
  getWageRules: function()   { return this._load().lists.wageRules || []; },
  getWageConfig: function()  { return this._load().lists.wageConfig || { distributableRatio: 0.625 }; },

  // ── Wage Distribution Calculator ──
  calculateWages: function(jobId, distributableBase) {
    var d = this._load();
    var payments = d.payments.filter(function(p) { return p.jobId === jobId; });
    var totalPaid = payments.reduce(function(sum, p) { return sum + p.amount; }, 0);
    var base = (distributableBase != null) ? distributableBase
      : Math.round(totalPaid * d.lists.wageConfig.distributableRatio);
    var rules = d.lists.wageRules || [];
    var staffList = d.lists.staff || [];
    var breakdown = [];
    staffList.forEach(function(s) {
      if (!s.roles || s.roles.length === 0) return;
      var staffPct = 0;
      s.roles.forEach(function(r) {
        var rule = rules.find(function(rl) { return rl.role === r; });
        if (rule) staffPct += rule.percentage;
      });
      if (staffPct === 0) return;
      breakdown.push({
        staffName: s.name,
        role: s.role,
        roles: s.roles,
        percentage: staffPct,
        amount: Math.round(base * staffPct)
      });
    });
    // Fix rounding: if total ≠ base, adjust the largest amount
    var sum = breakdown.reduce(function(acc, b) { return acc + b.amount; }, 0);
    var diff = base - sum;
    if (diff !== 0 && breakdown.length > 0) {
      breakdown.sort(function(a, b) { return b.amount - a.amount; });
      breakdown[0].amount += diff;
    }
    return { jobId: jobId, totalPaid: totalPaid, distributableBase: base, breakdown: breakdown };
  },

  // ── Wage Distributions ──
  getWageDistributions: function() {
    return this._load().wageDistributions || [];
  },
  getWageDistributionsByJob: function(jobId) {
    return (this._load().wageDistributions || []).filter(function(w) { return w.jobId === jobId; });
  },
  addWageDistribution: function(wd) {
    var d = this._load();
    if (!d.wageDistributions) d.wageDistributions = [];
    wd.id = generateId('WD', d.wageDistributions);
    d.wageDistributions.push(wd);
    this._save();
    return wd;
  },
  deleteWageDistribution: function(id) {
    var d = this._load();
    if (!d.wageDistributions) return false;
    var idx = d.wageDistributions.findIndex(function(w) { return w.id === id; });
    if (idx === -1) return false;
    d.wageDistributions.splice(idx, 1);
    this._save();
    return true;
  },

  // ── Wage Settings (editable) ──
  updateWageRules: function(rules) {
    var d = this._load();
    d.lists.wageRules = rules;
    this._save();
  },
  updateWageConfig: function(config) {
    var d = this._load();
    d.lists.wageConfig = config;
    this._save();
  },
  updateStaffRoles: function(staffName, roles) {
    var d = this._load();
    var s = d.lists.staff.find(function(x) { return x.name === staffName; });
    if (!s) return false;
    s.roles = roles;
    this._save();
    return true;
  },

  // ── Export / Import ──
  exportData: function() {
    var data = this._load();
    var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'photo-tracker-backup-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  importData: function(jsonString) {
    var data = JSON.parse(jsonString);
    if (!data.jobs || !data.payments || !data.tasks || !data.lists) {
      throw new Error('Invalid backup file: missing required sections (jobs, payments, tasks, lists)');
    }
    // Ensure new wage fields exist for backward compatibility
    if (!data.wageDistributions) data.wageDistributions = [];
    if (!data.lists.wageRules) data.lists.wageRules = [];
    if (!data.lists.wageConfig) data.lists.wageConfig = { distributableRatio: 0.625 };
    if (data.lists.staff) {
      data.lists.staff.forEach(function(s) { if (!s.roles) s.roles = []; });
    }
    this._data = data;
    this._save();
  },

  // ── Metrics ──
  getMetrics: function() {
    var d = this._load();
    var m = computeMetrics(d.jobs, d.tasks);
    // Add wage metrics
    var wds = d.wageDistributions || [];
    m.totalWageRecords = wds.length;
    m.totalWagesCalculated = wds.reduce(function(sum, w) { return sum + (w.distributableBase || 0); }, 0);
    return m;
  }
};
